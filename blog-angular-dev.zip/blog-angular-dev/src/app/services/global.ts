export var Global = {
    url: 'http://localhost:3900/api/'
};

