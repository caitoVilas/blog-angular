export class Pelicula{

    // public title:string;
    // public year: number;
    // public image: string;

    // constructor(title, year, image){
    //     this.title = title;
    //     this.year = year;
    //     this.image = image;
    // } 

    // es lo mismo que hacer

    constructor(
        public title: string,
        public year: number,
        public image: string
    ){}
}